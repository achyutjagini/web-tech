<script>
var a = document.getElementById('a');
var b = document.getElementById('b');
var c = document.getElementById('c');
var d = document.getElementById('d');

a.addEventListener('click',cancel,true);
b.addEventListener('click',cancel,true);
c.addEventListener('click',cancel,false);
d.addEventListener('click',cancel,false);


function cancel(event){
  var logElem = event.currentTarget.id;
  console.log(logElem);
  if(logElem==='a') event.cancelBubble = true;
  
}

var e = document.getElementById('e');
var f = document.getElementById('f');
var g = document.getElementById('g');
var h = document.getElementById('h');

e.addEventListener('click',stop,true);
f.addEventListener('click',stop,true);
g.addEventListener('click',stop,false);
h.addEventListener('click',stop,false);


function stop(event){
  var logElem = event.currentTarget.id;
  console.log(logElem);
  if(logElem==='e') event.stopPropagation();
  
}
</script>