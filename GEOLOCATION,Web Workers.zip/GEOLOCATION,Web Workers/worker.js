this.onmessage = function(event) { 
	console.log("Message received: "+event.data);
} 
//Implementation of web worker thread code 
setInterval(function(){
	postMessage({"msg":"Sending data at ", "tstamp":new Date().getTime()})
}, 5000)